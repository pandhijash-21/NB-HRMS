#!/bin/sh
set -e

echo "==> Prisma generate"
npx prisma generate

echo "==> Prisma migrate deploy"
npx prisma migrate deploy || echo "migrate deploy skipped/failed — continuing"

# db push --accept-data-loss can drop live tables. Opt in only if you intend a schema sync.
if [ "${PRISMA_DB_PUSH:-}" = "true" ]; then
  echo "==> Prisma db push (PRISMA_DB_PUSH=true)"
  npx prisma db push --skip-generate
fi

echo "==> Starting API"
exec node dist/index.js
